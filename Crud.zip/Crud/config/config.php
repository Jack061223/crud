<?php

define("KEY_TOKEN","APR.wpc-354*");
define("MONEDA","$");
session_start();

?>