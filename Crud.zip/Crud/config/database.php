<?php
//se va a trabajar orientado a objetos y pdo
class Database {
    //nombre de la base de datos donde se encuentra
    private $hostname = "localhost";
    //nombre que le hemos puesto a nuestra base de datos
    private $database = "raspados";
    //usuario de la base de datos
    private $username = "root";
    //si tenemos contraseña en localhost o la que usas para ingresar a la base de datos
    private $password = "";
    //motor para ayudarnos a conectarnos a la base de datos
    private $charset = "utf8";

    //creamos una funcion que se llamara conectar
    function conectar()
    {
        try{
        $conexion = "mysql:host=" . $this->hostname . "; dbname=" . $this->database . "; charset=" . $this->charset;
        //Agregamos un arreglo
        $options = [
            //esto es una configuracion para hacer consultas reales y seguras
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES => false
        ];

        //instancia o variable
        $pdo = new PDO($conexion, $this->username, $this->password, $options);

        return $pdo;
    }catch(PDOExeption $e){
        echo 'Error conexion' .$e->getMessage();
        exit;
    }
    }
}

?>